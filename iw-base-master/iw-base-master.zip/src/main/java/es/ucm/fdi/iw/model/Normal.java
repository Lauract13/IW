package es.ucm.fdi.iw.model;

import javax.persistence.Entity;

@Entity
public class Normal extends User {
	
	public Normal() {
		// TODO Auto-generated constructor stub
	}

}
